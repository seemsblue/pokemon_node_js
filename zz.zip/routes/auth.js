const router = require('express').Router();

//회원기능 관련 라우터 등 여기로 분리

module.exports = router;